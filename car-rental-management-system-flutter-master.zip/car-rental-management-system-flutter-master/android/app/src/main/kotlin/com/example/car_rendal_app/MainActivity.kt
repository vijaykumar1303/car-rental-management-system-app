package com.example.car_rendal_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
